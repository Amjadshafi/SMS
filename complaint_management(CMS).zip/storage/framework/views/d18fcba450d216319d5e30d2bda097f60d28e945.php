        <aside class="left-sidebar sidebar-dark" id="left-sidebar">
          <div id="sidebar" class="sidebar sidebar-with-footer">
            <!-- Aplication Brand -->
            <div class="app-brand">
              <a href="<?php echo e(route('dashboard')); ?>">
                <img src="<?php echo e(asset('theme/images/logo.png')); ?>" alt="">
                <span class="brand-name"><?php echo e(!empty(Auth()->user()->organization->name) ? Auth()->user()->organization->name : "Admin"); ?></span>
              </a>
            </div>
            <!-- begin sidebar scrollbar -->
            <div class="sidebar-left" data-simplebar style="height: 100%;">
              <!-- sidebar menu -->
              <ul class="nav sidebar-inner" id="sidebar-menu">

                <!--       <li>
                    <a class="sidenav-item-link" href="index.html">
                      <i class="mdi mdi-briefcase-account-outline"></i>
                      <span class="nav-text">Business Dashboard</span>
                    </a>
                  </li>                        
                   -->
                <?php if(auth()->guard()->check()): ?>
                <?php if(in_array(Auth::user()->roles->first()->name, ['Super Admin'])): ?>
                <li>
                  <a class="sidenav-item-link" href="<?php echo e(route('dashboard')); ?>">
                    <i class="mdi mdi-chart-line"></i>
                    <span class="nav-text"><?php echo e(__("trans.Dashboard")); ?></span>
                  </a>
                </li>
                <?php else: ?>
                <li>
                  <a class="sidenav-item-link" href="<?php echo e(route('userdashboard')); ?>">
                    <i class="mdi mdi-account-details"></i>
                    <span class="nav-text"><?php echo e(__("trans.User Dashboard")); ?></span>
                  </a>
                </li>
                <?php endif; ?>

                <?php if(\Spatie\Permission\PermissionServiceProvider::bladeMethodWrapper('hasRole', ['Super Admin','Admin'])): ?>
                <li class="has-sub">
                  <a class="sidenav-item-link" href="javascript:void(0)" data-toggle="collapse" data-target="#settings" aria-expanded="false" aria-controls="settings">
                    <i class="mdi mdi-settings"></i>
                    <span class="nav-text"><?php echo e(__("trans.Permissions Hub")); ?></span> <b class="caret"></b>
                  </a>
                  <ul class="collapse" id="settings" data-parent="#sidebar-menu">
                    <div class="sub-menu">

                      <li>

                        <a class="sidenav-item-link" href="<?php echo e(route('roles.index')); ?>">
                          <span class="nav-text"><?php echo e(__("trans.Roles")); ?></span>
                        </a>

                      </li>

                      <li>
                        <a class="sidenav-item-link" href="<?php echo e(route('permissions.create')); ?>">
                          <span class="nav-text"><?php echo e(__("trans.Permissions")); ?></span>
                        </a>
                      </li>

                    </div>
                  </ul>
                </li>
                <?php endif; ?>

                <li class="has-sub">
                  <a class="sidenav-item-link" href="<?php echo e(route('complaints.manage_complaint')); ?>">
                    <i class="mdi mdi-settings-outline"></i>
                    <span class="nav-text"><?php echo e(__("trans.Manage Complaint")); ?></span> <b class="caret"></b>
                  </a>
                </li>
                <li class="has-sub">

                  <a class="sidenav-item-link" href="#" data-toggle="collapse" data-target="#Notification" aria-expanded="false" aria-controls="Notification">
                    <i class="mdi mdi-bell"></i>
                    <span class="nav-text"><?php echo e(__("trans.Notification")); ?></span> <b class="caret"></b>
                  </a>
                <li class="has-sub">
                  <a class="sidenav-item-link" href="javascript:void(0)" data-toggle="collapse" data-target="#file" aria-expanded="false" aria-controls="file">
                    <i class="mdi mdi-file"></i>
                    <span class="nav-text"><?php echo e(__("trans.Attachment File")); ?></span> <b class="caret"></b>
                  </a>
                  <ul class="collapse" id="file" data-parent="#sidebar-menu">
                    <div class="sub-menu">
                      <li>
                        <a href="<?php echo e(route('complaint.file')); ?>"><?php echo e(__("trans.Attachment File")); ?></a>
                      </li>
                    </div>
                  </ul>
                </li>
                <li class="has-sub">
                  <a class="sidenav-item-link" href="javascript:void(0)" data-toggle="collapse" data-target="#users" aria-expanded="false" aria-controls="users">
                    <i class="mdi mdi-account-multiple"></i>
                    <span class="nav-text"><?php echo e(__("trans.User")); ?></span> <b class="caret"></b>
                  </a>
                  <ul class="collapse" id="users" data-parent="#sidebar-menu">
                    <div class="sub-menu">

                      <?php if(\Spatie\Permission\PermissionServiceProvider::bladeMethodWrapper('hasRole', ['Super Admin','Admin','User'])): ?>
                      <li>
                        <a class="sidenav-item-link" href="<?php echo e(route('users.index')); ?>">
                          <span class="nav-text"><?php echo e(__("trans.Users")); ?></span>
                        </a>
                      </li>
                      <?php endif; ?>

                    </div>
                  </ul>
                </li>

                <?php if(\Spatie\Permission\PermissionServiceProvider::bladeMethodWrapper('hasRole', ['Super Admin','Admin'])): ?>
                <li class="has-sub">
                  <a class="sidenav-item-link" href="<?php echo e(route('organizationsList')); ?>" data-toggle="collapse" data-target="#Organization" aria-expanded="false" aria-controls="Organizations">
                    <i class="mdi mdi-school"></i>
                    <span class="nav-text"><?php echo e(__("trans.Organizations")); ?></span> <b class="caret"></b>
                  </a>
                  <ul class="collapse" id="Organization" data-parent="#sidebar-menu">
                    <div class="sub-menu">

                      <li>
                        <a class="sidenav-item-link" href="<?php echo e(route('organizationsList')); ?>">
                          <span class="nav-text"><?php echo e(__("trans.All Oganizations")); ?></span>
                        </a>
                      </li>

                    </div>
                  </ul>
                </li>
                <?php endif; ?>
                <?php if(\Spatie\Permission\PermissionServiceProvider::bladeMethodWrapper('hasRole', ['Super Admin','Admin','User'])): ?>
                <li class="has-sub">
                  <a class="sidenav-item-link" href="<?php echo e(route('allcommittees')); ?>" data-toggle="collapse" data-target="#committee" aria-expanded="false" aria-controls="committee">
                    <i class="mdi mdi-account-details"></i>
                    <span class="nav-text"><?php echo e(__("trans.Inquiry Committee")); ?></span> <b class="caret"></b>
                  </a>
                  <ul class="collapse" id="committee" data-parent="#sidebar-menu">
                    <div class="sub-menu">
                      <?php if(Auth::user()->role === 'Super Admin'): ?>
                      <li>
                        <a class="sidenav-item-link" href="<?php echo e(route('allcommittees')); ?>">
                          <span class="nav-text"><?php echo e(__("trans.All Committees")); ?></span>
                        </a>
                      </li>
                      <?php endif; ?>
                      
                    </div>
                  </ul>
                </li>
                </li>
                <?php endif; ?>

                <?php if(\Spatie\Permission\PermissionServiceProvider::bladeMethodWrapper('hasRole', 'Super Admin')): ?>
                <li class="has-sub">
                  <a class="sidenav-item-link" href="<?php echo e(route('categories.all')); ?>" data-toggle="collapse" data-target="#Category" aria-expanded="false" aria-controls="Category">
                    <i class="mdi mdi-format-list-bulleted"></i>
                    <span class="nav-text"><?php echo e(__("trans.Category")); ?></span> <b class="caret"></b>
                  </a>
                  <ul class="collapse" id="Category" data-parent="#sidebar-menu">
                    <div class="sub-menu">
                      <li>
                        <a class="sidenav-item-link" href="<?php echo e(route('categories.all')); ?>">
                          <span class="nav-text"><?php echo e(__("trans.All Category")); ?></span>
                        </a>
                      </li>
                    </div>
                  </ul>
                </li>
                <?php endif; ?>

                <li class="has-sub">
                  <a class="sidenav-item-link" href="javascript:void(0)" data-toggle="collapse" data-target="#Complaints" aria-expanded="false" aria-controls="Complaints">
                    <i class="mdi mdi-dropbox"></i>
                    <span class="nav-text"><?php echo e(__("trans.Complaints")); ?></span> <b class="caret"></b>
                  </a>
                  <ul class="collapse" id="Complaints" data-parent="#sidebar-menu">
                    <div class="sub-menu">
                      <li>
                        <a href="<?php echo e(route('complaint.index')); ?>">
                          <span class="nav-text"><?php echo e(__("trans.All Complaints")); ?></span>
                        </a>
                      </li>
                      <?php if(\Spatie\Permission\PermissionServiceProvider::bladeMethodWrapper('hasRole', ['Super Admin','Admin'])): ?>
                      <li>
                        <a href="<?php echo e(route('createComplaint')); ?>"><span class="nav-text"><?php echo e(__("trans.Create New Complaint")); ?></span></a>
                      </li>
                      <?php endif; ?>

                      <li>
                        <a href="<?php echo e(route('complaint.pending')); ?>">
                          <span class="nav-text"><?php echo e(__("trans.Pending Complaints")); ?></span>
                        </a>
                      </li>
                      <li>
                        <a href="<?php echo e(route('complaint.inprocess')); ?>"><span class="nav-text"><?php echo e(__("trans.In Process")); ?></span></a>
                      </li>
                      <li>
                        <a href="<?php echo e(route('complaint.cancelled')); ?>"><span class="nav-text"><?php echo e(__("trans.Cancelled Complaints")); ?></span></a>
                      </li>
                      <li>
                        <a href="<?php echo e(route('complaint.completed')); ?>"><span class="nav-text"><?php echo e(__("trans.Completed Complaints")); ?></span></a>
                      </li>
                    </div>
                  </ul>
                </li>
                <?php if(\Spatie\Permission\PermissionServiceProvider::bladeMethodWrapper('hasRole', 'Super Admin')): ?>
                <li class="has-sub">
                  <a class="sidenav-item-link" href="javascript:void(0)" data-toggle="collapse" data-target="#Report" aria-expanded="false" aria-controls="Report">
                    <i class="mdi mdi-database"></i>
                    <span class="nav-text"><?php echo e(__("trans.Report")); ?></span> <b class="caret"></b>
                  </a>
                  <ul class="collapse" id="Report" data-parent="#sidebar-menu">
                    <div class="sub-menu">
                      <li>
                        <a class="sidenav-item-link" href="<?php echo e(route('complaints.assigned_complaint_summary')); ?>">
                          <span class="nav-text"><?php echo e(__("trans.Assigned To Summary")); ?></span>
                        </a>
                      </li>
                      <li>
                        <a class="sidenav-item-link" href="<?php echo e(route('complaints.status_summary')); ?>">
                          <span class="nav-text"><?php echo e(__("trans.Complaint Status Summary")); ?></span>
                        </a>
                      </li>
                      <div>
                  </ul>
                </li>
                <?php endif; ?>
                <?php endif; ?>
              </ul>
            </div>
          </div>
        </aside><?php /**PATH C:\xampp\htdocs\complaint_management\resources\views/layouts/partials/side_navbar.blade.php ENDPATH**/ ?>