
<?php $__env->startSection('pageTitle', __("trans.Add New Committee")); ?>
<?php $__env->startSection('content'); ?>
<style>
    .form-group {
        margin-bottom: 20px;
    }

    h2 {
        margin-top: 20px;
        /* Adjust the value as needed */
    }
</style>
<div class="card ml-8 mr-8">
    <div class="form-group col-12">
        <h2 class="text-center mb-4"><?php echo e(__("trans.Committee Form")); ?></h2>
        <form action="<?php echo e(route('committee.store')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label for="name" class="text-center mb-4"><?php echo e(__("trans.Committee Name")); ?></label>
                <input type="text" name="name" class="form-control" required>
            </div>
            <div class="form-group">
                <label for="organization_id"><?php echo e(__("trans.Organization")); ?></label>
                <select name="organization_id" class="form-control" required>
                    <option value=""><?php echo e(__("trans.Select Organization")); ?></option>
                    <?php $__currentLoopData = $organizations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $organization): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($organization->id); ?>"><?php echo e($organization->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="form-group">
                <label for="user_id"><?php echo e(__("trans.Select Members")); ?></label>
                <select name="user_id[]" id="user_id" class="select2-original" required multiple>
                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($user->id); ?>"><?php echo e($user->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <button type="submit" class="btn btn-primary"><?php echo e(__("trans.Submit")); ?></button>
            <a href="<?php echo e(url()->previous()); ?>" type="button" class="btn tumblr"><?php echo e(__("trans.Cancel")); ?></a>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<script>
    $('.select2-original').select2({
    	placeholder: "<?php echo e(__('trans.Choose Team Members')); ?>",
      width: "100%"
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app-master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\complaint_management\resources\views/committee/create.blade.php ENDPATH**/ ?>