

<?php $__env->startSection('pageTitle', __("trans.Status Summary")); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
<div id="status-summary-container" class="card ml-1 mr-1">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-9">
                <h3 class="mb-4"><b><?php echo e(__("trans.Complaint Status Summary Report")); ?></b></h3>
            </div>
        </div>

        <div class="row">
            <div class="col-md-4">
                <div class="form-group">
                    <label for="StartDate"><?php echo e(__("trans.Start Date")); ?></label>
                    <input type="date" id="StartDate" class="form-control" required="">
                </div>
            </div>
            <div class="col-md-4">
                <div class="form-group">
                    <label for="EndDate"><?php echo e(__("trans.End Date")); ?></label>
                    <input type="date" id="EndDate" class="form-control" required="">
                </div>
            </div>
            <div class="col-md-4">
                <div class="form-group">
                    <div class="btn-toolbar" role="toolbar">
                        <div class="btn-group mr-2">
                            <button type="button" onclick="ComplaintStatusSummaryReportCustomRange(document.getElementById('StartDate').value,document.getElementById('EndDate').value)" class="btn btn-primary">Submit</button>
                            <button type="button" onclick="ResetStatusSummaryReport()" class="btn btn-success">Reset</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-md-10">
            <table class="table table-bordered table-striped">
                <thead>
                    <tr>
                        <th><?php echo e(__("trans.Current Status")); ?></th>
                        <th><?php echo e(__("trans.Number of Complaints")); ?></th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $statusCounts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status => $count): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($status); ?></td>
                            <td><?php echo e($count); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
    function ComplaintStatusSummaryReportCustomRange(startDate, endDate) {
        $.ajax({
            type: 'GET',
            url: '<?php echo e(route("complaints.status_summary")); ?>',
            data: {
                StartDate: startDate,
                EndDate: endDate
            },
            success: function(data) {
                $('#status-summary-container').html(data);
            },
            error: function(xhr, status, error) {
                console.error(error);
            }
        });
    }

    function ResetStatusSummaryReport() {
        $('#StartDate').val('');
        $('#EndDate').val('');
        $('#status-summary-container').empty();
    }
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app-master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\complaint_management\resources\views/complaints/status_summary.blade.php ENDPATH**/ ?>