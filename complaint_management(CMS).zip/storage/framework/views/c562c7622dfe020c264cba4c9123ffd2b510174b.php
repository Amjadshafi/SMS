

<?php $__env->startSection('pageTitle', __("trans.Assigned Complaint Summary")); ?>

<?php $__env->startSection('content'); ?>

<div class="card ml-1 mr-1">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12">
                <h3 class="mb-4"><b><?php echo e(__("trans.Assigned Complaint Summary")); ?></b></h3>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-md-4">
            <div class="form-group">
                <label for="StartDate"><?php echo e(__("trans.Start Date")); ?></label>
                <input type="date" id="StartDate" name="StartDate" class="form-control" required="">
            </div>
        </div>
        <div class="col-md-4">
            <div class="form-group">
                <label for="EndDate"><?php echo e(__("trans.End Date")); ?></label>
                <input type="date" id="EndDate" name="EndDate" class="form-control" required="">
            </div>
        </div>
        <div class="col-md-4">
            <div class="form-group">
                <button type="button" onclick="filterComplaints()" class="btn btn-primary"><?php echo e(__("trans.Submit")); ?></button>
                <button type="button" onclick="resetFilters()" class="btn btn-success"><?php echo e(__("trans.Reset")); ?></button>
            </div>
        </div>
    </div>
    <div class="col-md-10">
        <table class="ItemTranTable">
            <thead>
                <tr>
                    <th>#</th>
                    <th><?php echo e(__("trans.Assigned User")); ?></th>
                    <th><?php echo e(__("trans.Total Assigned")); ?></th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $assignedComplaints; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $assignedComplaint): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($index + 1); ?></td>
                    <td><?php echo e($assignedComplaint->assigned_user); ?></td>
                    <td><?php echo e($assignedComplaint->total); ?></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>

</div>

<script>
    function filterComplaints() {
        var startDate = document.getElementById('StartDate').value;
        var endDate = document.getElementById('EndDate').value;
        window.location.href = "<?php echo e(route('complaints.assigned_complaint_summary')); ?>?StartDate=" + startDate + "&EndDate=" + endDate;
    }

    function resetFilters() {
        document.getElementById('StartDate').value = '';
        document.getElementById('EndDate').value = '';
        filterComplaints();
    }
</script>
<?php $__env->stopSection(); ?>

































<style>
    .ItemTranTable {
        width: 100%;
        border-collapse: collapse;
    }

    .ItemTranTable th,
    .ItemTranTable td {
        border: 1px solid #dddddd;
        padding: 8px;
        text-align: left;
    }

    .ItemTranTable th {
        background-color: #f2f2f2;
    }

    .ItemTranTable tbody tr:nth-child(even) {
        background-color: #f9f9f9;
    }

    .ItemTranTable tbody tr:hover {
        background-color: #ddd;
    }
</style>
<?php echo $__env->make('layouts.app-master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\complaint_management\resources\views/complaints/assigned_complaint_summary.blade.php ENDPATH**/ ?>