
<?php $__env->startSection('pageTitle',__('trans.All Committees')); ?>
<?php $__env->startSection('content'); ?>

<div class="mt-2">
    <?php echo $__env->make('layouts.partials.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>
<div class="card ml-1 mr-1">
    <div class="card-header">
        <a href="<?php echo e(route('committee.create')); ?>" class="btn btn-primary btn-sm float-right"><?php echo e(__("trans.AddNew")); ?></a>
    </div>
    <div class="card-body">
        <table id="data-table" class="table display" cellspacing="0" width="100%">
            <thead>
                <tr>
                    <th><?php echo e(__("trans.ID #")); ?></th>
                    <th><?php echo e(__("trans.Name")); ?></th>
                    <th>Members</th>
                    <th><?php echo e(__("trans.Actions")); ?></th>
                </tr>
            </thead>

            <tfoot>
                <tr>
                    <th><?php echo e(__("trans.ID #")); ?></th>
                    <th><?php echo e(__("trans.Name")); ?></th>
                    <th>Members</th>
                    <th><?php echo e(__("trans.Actions")); ?></th>
                </tr>
            </tfoot>

            <tbody>
                <?php $__currentLoopData = $committees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $committee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e(++$key); ?></td>
                    <td><?php echo e($committee->name); ?></td>
                    <td>
                        <ul>
                        <?php $__currentLoopData = $committee->users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($user->name); ?></li>
                        
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </td>
                    <td>
                        <a title="Show" href="<?php echo e(route('committee.show', $committee->id)); ?>"><i class="mdi mdi-eye-outline"></i></a>
                        <a title="Edit" href="<?php echo e(route('committee.edit', $committee->id)); ?>"><i class="mdi mdi-square-edit-outline"></i></a>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app-master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\complaint_management\resources\views/committee/index.blade.php ENDPATH**/ ?>