<?php

return [
    'test' => [
        'welcome' => 'Welcome to our website!',
        'goodbye' => 'Goodbye!',
    ],
    'validation_message' => [
        'username_unique' => "Username already in use."
    ]
];
